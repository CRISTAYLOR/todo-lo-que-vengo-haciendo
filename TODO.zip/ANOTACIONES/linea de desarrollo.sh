linea de desarrollo
-------------------

git log
creas rama

git branch
guardas cambios
git add

comentas 
git commit
para ver las diferencias luego del comiit 
-- chache


envias al repositorio
git push
pull request
ver diferencias
git diff

git merge
para enviar los cambios finales al repositorio



